# CART3R Chess

Protótipo Android nativo em Kotlin + Jetpack Compose.

## Abrir
1. Instale o Android Studio.
2. Abra a pasta `CART3RChess`.
3. Aguarde a sincronização do Gradle.
4. Execute no emulador ou em um Android com depuração USB ativada.

## Estado desta versão
- Interface escura roxa.
- Navegação Início / Tabuleiro / Estudo.
- Tabuleiro visual com seleção de casas.
- Sem login ou conexão com Chess.com.

## Ainda não implementado
- Regras legais de xadrez e execução de movimentos.
- Integração com Stockfish.
- Importação e análise de PGN.
- APK assinado e publicação na Play Store.

Este é um projeto-fonte inicial, não um APK pronto para instalar.
