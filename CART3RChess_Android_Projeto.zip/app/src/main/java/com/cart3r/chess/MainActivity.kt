package com.cart3r.chess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF100D18)
private val Panel = Color(0xFF201A2D)
private val Purple = Color(0xFFB58CFF)
private val Muted = Color(0xFFBDB3CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Cart3rApp() }
    }
}

@Composable
fun Cart3rApp() {
    var page by remember { mutableStateOf("Início") }
    var selected by remember { mutableStateOf<Int?>(null) }
    val initial = listOf(
        "r","n","b","q","k","b","n","r",
        "p","p","p","p","p","p","p","p",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "","","","","","","","",
        "P","P","P","P","P","P","P","P",
        "R","N","B","Q","K","B","N","R"
    )
    var board by remember { mutableStateOf(initial) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Início", "Tabuleiro", "Estudo").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item; selected = null },
                        icon = {
                            Icon(when(item) {
                                "Tabuleiro" -> Icons.Default.Analytics
                                "Estudo" -> Icons.Default.School
                                else -> Icons.Default.Bolt
                            }, contentDescription = item)
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Purple, selectedTextColor = Purple,
                            indicatorColor = Color(0xFF392B50),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("CART3R", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("CHESS MOD", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    }
                    Surface(color = Color(0xFF183324), shape = RoundedCornerShape(50)) {
                        Text("● SAFE MODE", color = Color(0xFF8EE0A5),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(22.dp))
                when(page) {
                    "Tabuleiro" -> {
                        Text("TABULEIRO DE ESTUDO", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        ChessBoard(board, selected) { index ->
                            selected = if (selected == index) null else index
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Toque nas casas para selecionar. Este protótipo ainda não valida movimentos.",
                            color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = {
                            board = initial
                            selected = null
                        }) { Text("Reiniciar posição") }
                    }
                    "Estudo" -> {
                        FeatureCard("Análise de partidas", "Área preparada para revisar partidas concluídas.", Icons.Default.Analytics)
                        FeatureCard("Importar PGN", "Importação de arquivos será adicionada na próxima etapa.", Icons.Default.FileOpen)
                        FeatureCard("Stockfish", "O motor de análise ainda não está incluído nesta versão inicial.", Icons.Default.Bolt)
                    }
                    else -> {
                        Text("SEU ESPAÇO DE ANÁLISE", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("Estude xadrez. Evolua jogada por jogada.", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Aplicativo independente para treino e análise de partidas finalizadas. Não se conecta à sua conta Chess.com.",
                                    color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        FeatureCard("Tabuleiro interativo", "Visualize a posição inicial e selecione casas.", Icons.Default.Analytics)
                        FeatureCard("Modo seguro", "Sem automação, sobreposição ou assistência durante partidas online.", Icons.Default.School)
                        Spacer(Modifier.weight(1f))
                        Text("CART3R CHESS • VERSÃO 0.1 • PROTÓTIPO", color = Muted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Purple, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(description, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
    }
}

@Composable
private fun ChessBoard(board: List<String>, selected: Int?, onTap: (Int) -> Unit) {
    val pieces = mapOf("k" to "♚", "q" to "♛", "r" to "♜", "b" to "♝", "n" to "♞", "p" to "♟",
        "K" to "♔", "Q" to "♕", "R" to "♖", "B" to "♗", "N" to "♘", "P" to "♙", "" to "")
    Column(Modifier.fillMaxWidth()) {
        for (row in 0..7) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0..7) {
                    val i = row * 8 + col
                    val light = (row + col) % 2 == 0
                    val base = if (light) Color(0xFFE8D8C4) else Color(0xFF80618E)
                    Box(
                        Modifier.weight(1f).aspectRatio(1f)
                            .background(if (selected == i) Color(0xFFFFD45C) else base)
                            .clickable { onTap(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(pieces[board[i]] ?: "", fontSize = 30.sp,
                            color = if (board[i].firstOrNull()?.isUpperCase() == true) Color.White else Color(0xFF17131D))
                    }
                }
            }
        }
    }
}
